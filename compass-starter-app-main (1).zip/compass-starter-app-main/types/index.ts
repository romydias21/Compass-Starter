import * as Page from './pages'
import * as App from './app'
import * as Component from './components'
import * as Common from './common'

import * as Generic from './generic'

export { Generic, Common, Component, Page, App }
